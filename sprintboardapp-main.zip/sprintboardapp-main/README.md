# Sprint Board App

Pipeline status:

[![Build and Deploy to AWS](https://github.com/ankit-antony-devops/jira-app-mern/actions/workflows/pipeline.yml/badge.svg)](https://github.com/ankit-antony-devops/jira-app-mern/actions/workflows/pipeline.yml)
